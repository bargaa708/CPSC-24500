/* 
 * This is the BusinessLoan class which extends Loan and implements LoanConstants
 * effectively it calculates the interest required for the abstract class.
 * Assignment: #7 Midterm
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 */

public class BusinessLoan extends Loan implements LoanConstants{
	private double intRate;
	
	public BusinessLoan(String loanNumber, String lastName, double loanAmt, int term, double intRate) {
		super(loanNumber, lastName, loanAmt, term);
		this.intRate = intRate + 1.00;
	}

	public double getIntRate() {
		return intRate;
	}

	public void setIntRate(double intRate) {
		this.intRate = intRate;
	}

}
