/*
 * This is the LoanConstant interface which provides the constants for 
 * the other classed constants like the term length, maximum loan amount and 
 * the company name.
 * Assignment: #7 Midterm
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 */

public interface LoanConstants {
	int shortTerm = 1;
	int mediumTerm = 3;
	int longTerm = 5;
	double maximumLoanAmt = 500000;
	String compName = "Care Construction Loan Company";	
}
