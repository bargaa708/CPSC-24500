/*
 * This is the Super Loan() class which is an abstract
 * super class, that contains protected variable types: Loan number,
 * Last name, loan amount, term length and an abstract function to get
 * the interest rate.
 * Assignment: #7 Midterm
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 */

public abstract class Loan implements LoanConstants{
	private String loanNumber;
	private String lastName;
	private double loanAmt;
	private int term;
	public abstract double getIntRate();
	
	public Loan(String loanNumber, String lastName, double loanAmt, int term) {
		super();
		this.loanNumber = loanNumber;
		this.lastName = lastName;
		switch (term) {
		case 1: this.term = shortTerm; break;
		case 2: this.term = mediumTerm; break;
		case 3: this.term = longTerm; break;
		default: this.term = shortTerm; break;
		}
		if(loanAmt > maximumLoanAmt) {
			this.loanAmt = Double.NaN;
		}
		else this.loanAmt = loanAmt;
	}
	@Override
	public String toString() {
		if (Double.isNaN(loanAmt)) {
			return "Sorry, but the loan amount you are applying for is \nover our maximum loan amount policy and cannot be made.";
		}
		else {
			return  "Loan ID Number: \t" + loanNumber + "\nApplicant Last Name: \t" + lastName + "\nLoan Amount: \t\t" 
				+ loanAmt + "\nLoan Term Length: \t" + term + "\nInterest Rate: \t\t" + getIntRate();
		}
	}	
}
