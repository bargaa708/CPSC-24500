/*
 * This is the loan program from assignment #9 however, this specific
 * program was modified to run as a gui Program.
 * Assignment: #10 GUI
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

public class LoanTypeEvent extends JFrame{
	private JLabel jlLoanType = new JLabel("Loan Type:");
	private JRadioButton jrbtBusiness = new JRadioButton("Business Loan");
	private JRadioButton jrbtPersonal = new JRadioButton("Personal Loan");
	private ButtonGroup g1 = new ButtonGroup();
	
	private JLabel jlLoanTerm = new JLabel("Loan Term (Years):");
	private JRadioButton jrbt1year = new JRadioButton("1");
	private JRadioButton jrbt3year = new JRadioButton("3");
	private JRadioButton jrbt5year = new JRadioButton("5");
	private ButtonGroup g2 = new ButtonGroup();
	
	private JLabel jlLastName = new JLabel("Last Name:");
	private JTextField jtfLastName = new JTextField(10);
	
	private JLabel jlamount = new JLabel("Loan Amount:");
	private JTextField jtfamount = new JTextField(10);
	
	private JButton jbtSubmit = new JButton("Submit");
	//variables to store input
	private int type1;
	private int term;
	private double amount;
	double primeRate;
	private String name;
	private String loanNumber;
	private ArrayList<Loan> list = new ArrayList<Loan>();	
	
	public int getTerm() {
		return term;
	}
	public void setTerm(int term) {
		this.term = term;
	}

	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public int getType1() {
		return type1;
	}
	public void setType1(int type) {
		this.type1 = type;
	}

	public double getPrimeRate() {
		return primeRate;
	}
	public void setPrimeRate(double primeRate) {
		this.primeRate = primeRate;
	}
	
	public String getLoanNumber() {
		return loanNumber;
	}
	public void setLoanNumber(String loanNumber) {
		this.loanNumber = loanNumber;
	}
	
	public ArrayList<Loan> getList() {
		return list;
	}
	public void setList(ArrayList<Loan> list) {
		this.list = list;
	}
	
	public LoanTypeEvent() {
		setSize(400,400);
	    setLayout(new GridLayout(6, 1));
	    
	    //create flowlayout panel for each feature
	    JPanel loanTypePanel = new JPanel();
	    loanTypePanel.setLayout(new FlowLayout());
	    loanTypePanel.add(jlLoanType);
	    loanTypePanel.add(jrbtBusiness);
	    loanTypePanel.add(jrbtPersonal);
	    g1.add(jrbtBusiness); g1.add(jrbtPersonal);   
	    
	    JPanel lastNamePanel = new JPanel();
	    lastNamePanel.setLayout(new FlowLayout());
	    lastNamePanel.add(jlLastName);
	    lastNamePanel.add(jtfLastName);
	    
	    JPanel amountPanel = new JPanel();
	    amountPanel.setLayout(new FlowLayout());
	    amountPanel.add(jlamount);
	    amountPanel.add(jtfamount);
	    
	    JPanel termPanel = new JPanel();
	    termPanel.setLayout(new FlowLayout());
	    termPanel.add(jlLoanTerm);
	    termPanel.add(jrbt1year);
	    termPanel.add(jrbt3year);
	    termPanel.add(jrbt5year);
	    g2.add(jrbt1year); g2.add(jrbt3year); g2.add(jrbt5year);
	    
	    JPanel submitPanel = new JPanel();
	    submitPanel.setLayout(new FlowLayout());
	    submitPanel.add(jbtSubmit);
	    
	    //add panels to the frame
	    add(loanTypePanel);
	    add(lastNamePanel);
	    add(amountPanel);
	    add(termPanel);
	    add(submitPanel);
	    
		Random num = new Random();
		int number = num.nextInt(999999);
		this.loanNumber = Integer.toString(number);
	 
	 jbtSubmit.addActionListener (new ActionListener() {
		 public void actionPerformed(ActionEvent e) {
			 if(jrbtBusiness.isSelected()) {
				 LoanTypeEvent.this.type1 = 1;
			 }
			 if(jrbtPersonal.isSelected()) { 
				 LoanTypeEvent.this.type1 = 2;
			 }
			 if(jrbt1year.isSelected()) { 
				 LoanTypeEvent.this.term = 1;
			 }
			 if(jrbt3year.isSelected()) { 
				 LoanTypeEvent.this.term = 3;
			 }
			 if(jrbt5year.isSelected()) { 
				 LoanTypeEvent.this.term = 5;
			 }
			 LoanTypeEvent.this.name = jtfLastName.getText();
			 String temp = jtfamount.getText();
			 LoanTypeEvent.this.amount = Double.parseDouble(temp);
			 if(type1 == 1){
			 		list.add(new BusinessLoan(loanNumber, name, amount, term, primeRate));
			 	}
			 if(type1 == 2){
			 	list.add(new BusinessLoan(loanNumber, name, amount, term, primeRate));
			 }
			 for(int x = 0; x < list.size(); x++) {
				Loan loan = list.get(x);
				System.out.println("\n" + loan.toString());
			 }
		 }
	 });//action listener
	 	
	}//constructor
	 
	 public static void main(String[] args) {
		 LoanTypeEvent LoanFrame = new LoanTypeEvent();
		 String primeRateQ  = "Please enter the current Prime interest rate: ";
		 String primeRateIN = JOptionPane.showInputDialog(primeRateQ);
		 LoanFrame.setPrimeRate(Double.parseDouble(primeRateIN));

		 LoanFrame.setTitle("LoanTypeEvent");
		 LoanFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 LoanFrame.setVisible(true);
	 }
//	 jbtClose.addActionListener (new ActionListener() {
//		 public void actionPerformed(ActionEvent e) {
//			 LoanTypeEvent.this.type = 1;
//		 }
//	 });
	
}
