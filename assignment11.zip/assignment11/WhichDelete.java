/*
 * This is the delete class displays an information pane asking the user to 
 * input a user or Person object to delete from our arrayList.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class WhichDelete {

	String temp;//temp variable to recieve user input the variable will then be parced
	int user;
	Person person;
	
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	
	private ArrayList<Person> arrayList = new ArrayList<Person>();

	public WhichDelete(ArrayList<Person> arraylist) {
		this.arrayList = arraylist;
		int size = arrayList.size() - 1;
		temp = JOptionPane.showInputDialog("Which user would you like to Delete (enter a "
				+ "user number (0 - " + size + "):");
		
		user = Integer.parseInt(temp);//parse temp variable so it can be retrieved in the Updatewindow
		person = arrayList.get(user);
		
		JOptionPane.showMessageDialog(null, "User " + person.getName() + " has been deleted.");
		arrayList.remove(user);
		Menu menu = new Menu();
		menu.setArrayList(arrayList);
		
	}
	
}

