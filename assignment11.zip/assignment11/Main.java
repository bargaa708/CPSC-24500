/*
 * This is the Main class/method it simply just call/starts
 * the GUI
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

public class Main {

	public static void main(String[] args) {
		Menu menu = new Menu();
	}
}
