/*
 * This is the save class/pane respons to the save button when pressed 
 * in the main GUI it asks the user for filename to save to and calls the 
 * serializer class to serialize the Person type arraylist.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class SavePane {
	private String fileName;	
	private ArrayList<Person> arrayList = new ArrayList<Person>();

	public SavePane(ArrayList<Person> arraylist) {
		this.arrayList = arraylist;
			
		fileName = JOptionPane.showInputDialog("Please enter the name of the file:");
		
		Serializer serialize = new Serializer();
		serialize.serialize(arrayList, fileName);
		
		Menu menu = new Menu();
		menu.setArrayList(arrayList);
		
	}
}
