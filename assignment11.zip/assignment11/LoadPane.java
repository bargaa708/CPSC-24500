/*
 * This is the Load class/pane it opens information option
 * pane takes the user input and passes necessary information
 * to the serializer class.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */
package assignment11;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class LoadPane {
	private String fileName;	
	private ArrayList<Person> arrayList = new ArrayList<Person>();

	public LoadPane() {	
		fileName = JOptionPane.showInputDialog("Please enter the name of the file:");
		
		Serializer serialize = new Serializer();
		serialize.deserialize(fileName);
		
		//Menu menu = new Menu();
		//menu.setArrayList(arrayList);
		
	}
}
