/*
 * This is the add class the most comprehensive it takes user input for 
 * Name, number, DOB, email inputs creates a Person object with those 
 * inputs and stores it in the Person type arraylist.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.ArrayList;

public class AddWindow extends JFrame implements ActionListener{
	//create panels
	private JPanel panel1 = new JPanel();
	private JPanel panel2 = new JPanel();
	private JPanel panel3 = new JPanel();
	private JPanel panel4 = new JPanel();
	private JPanel panel5 = new JPanel();
	
	//create textfields
	private JTextField nameField = new JTextField(10);
	private JTextField numberField = new JTextField(10);
	private JTextField dayField = new JTextField();
	private JTextField monthField = new JTextField();
	private JTextField yearField = new JTextField();
	private JTextField emailField = new JTextField();
	
	//create labels
	private JLabel namelabel = new JLabel("Enter Name:");
	private JLabel numberlabel = new JLabel("Enter Phone Number:");
	private JLabel doblabel = new JLabel("Enter Date of Birth (mm/dd/yyyy):");
	private JLabel emaillabel = new JLabel("Enter Email:");
	
	//create button
	private JButton add = new JButton("Add");
	
	//object variables
	private Person person;
	private String name;
	private long number;
	private Hashtable<String, Integer> dob = new Hashtable<String, Integer>();
	private String d = "Day";
	private String m = "Month";
	private String y = "Year";
	private int day;
	private int month;
	private int year;
	private String email;
	private ArrayList<Person> arrayList = new ArrayList<Person>();
	
	
	public AddWindow(ArrayList<Person> arrayList){
		this.arrayList = arrayList;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(400,300);
		this.setVisible(true);
		this.setLayout(new GridLayout(5,1));
		
		//set text field sizes
		nameField.setPreferredSize(new Dimension(200,30));
		numberField.setPreferredSize(new Dimension(200,30));
		dayField.setPreferredSize(new Dimension(30,30));
		monthField.setPreferredSize(new Dimension(30,30));
		yearField.setPreferredSize(new Dimension(50,30));
		emailField.setPreferredSize(new Dimension(200,30));
		//add labels to corresponding panels
		panel1.add(namelabel);panel2.add(numberlabel);panel3.add(doblabel);panel4.add(emaillabel);
		//add text fields to corresponding panels
		panel1.add(nameField);panel2.add(numberField);panel3.add(monthField);panel3.add(dayField);panel3.add(yearField);panel4.add(emailField);
		//add button to panel
		panel5.add(add);
		//add panels to frame
		this.add(panel1);this.add(panel2);this.add(panel3);this.add(panel4);this.add(panel5);
		
		add.addActionListener(this);		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==add) {
			name = nameField.getText();
			email = emailField.getText();
			String td = dayField.getText();
			day = Integer.parseInt(td);
			String tm = monthField.getText();
			month = Integer.parseInt(tm);
			String ty = yearField.getText();
			year = Integer.parseInt(ty);
			String tn = numberField.getText();
			number = Long.parseLong(tn);
			dob.put(d, day);
			dob.put(m, month);
			dob.put(y, year);
			person = new Person(name, number, dob, email);
			//Main main = null;
			arrayList.add(person);
			this.dispose();
			Menu menu = new Menu();
			menu.setArrayList(arrayList);
		
		}
		
	}
}
