/*
 * This is the serializer class the key learning objective for this
 * assignment it takes in user inputed arraylist of Person type object and
 * a filename and then serializes the objects to be stored in a file or it can 
 * also deserialize a file so that it can be processed.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.io.FileInputStream;
import javax.swing.JOptionPane;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Hashtable;

public class Serializer {
	private ArrayList<Person> data;
	private String fileName;

	public Serializer() {
		//this.data = data;
	}
	
	//Serialize data
	public void serialize(ArrayList<Person> data, String fileName1){
		this.data = data;
		this.fileName = fileName1;
		try {
			FileOutputStream fileOut = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(data);
			out.close();
			fileOut.close();
			JOptionPane.showMessageDialog(null, "***Serialized data is saved in: " + fileName + "***\n");
			//System.out.println("***Serialized data is saved in: " + fileName + "***\n");
		}
		catch(IOException i){
			i.printStackTrace();
		}
	}//serialize
	
	//De-serialize data
	public void deserialize(String fileName1){
		this.fileName = fileName1;
		//create arraylist to store deserialized objects
		ArrayList<Person> deserialized = new ArrayList<Person>();
			
		try {
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			deserialized = (ArrayList<Person>)in.readObject();
			in.close();
			fileIn.close();
		} catch(IOException i){
			i.printStackTrace();
			return;
		} catch(ClassNotFoundException c){
			c.printStackTrace();
			return;
		}
		
		//deserializer output string
		String displayStr = "";
		for(int x=0; x<deserialized.size(); x++) {
			Person person = deserialized.get(x);
			
			String retrievedName = person.getName();
			long retrievedNumber = person.getPhoneNum();
			Hashtable<String, Integer> retrievedDob = person.getDob();
			String retrievedEmail = person.getEmail();
			
			displayStr += "Name: " + retrievedName + "\nPhone Number: " + retrievedNumber + 
					"\nDate of Birth: " + retrievedDob.get("Month") + "/" + retrievedDob.get("Day") + "/" + retrievedDob.get("Year") +
					"\nEmail: " + retrievedEmail + "\n==========================\n\n";
			
			/*
			//Print everything to console
			System.out.println("Name: " + retrievedName);
			System.out.println("Phone Number: " + retrievedNumber);
			System.out.println("Date of Birth: " + retrievedDob.get("Month") + "/" + retrievedDob.get("Day") + "/" + retrievedDob.get("Year"));
			System.out.println("Email: " + retrievedEmail);
			System.out.println("\n==========================\n");
			*/		
		}//for loop
		/*
		JOptionPane.showMessageDialog(null, "Name: " + retrievedName + "\nPhone Number: " + retrievedNumber + 
				"\nDate of Birth: " + retrievedDob.get("Month") + "/" + retrievedDob.get("Day") + "/" + retrievedDob.get("Year") +
				"\nEmail: " + retrievedEmail + "\n\n==========================\n");
				*/
		JOptionPane.showMessageDialog(null, displayStr);
	}//deserializer
}
