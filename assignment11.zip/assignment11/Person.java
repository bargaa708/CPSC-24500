/*
 * This is the Person class this is used to create a person object
 * that contains a name, number, DOB, email. These objects will later be
 * stored in an arraylist and serialized onto a file
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.io.Serializable;
import java.util.Hashtable;

public class Person implements Serializable{
	private static final long serialVersionUID = 1L;
	private String name;
	private long phoneNum;
	private Hashtable<String, Integer> dob;
	private String email;
	
	
	public Person(String name,long phoneNum, Hashtable<String, Integer> dob, String email) {
		super();
		this.name = name;
		this.phoneNum = phoneNum;
		this.dob = dob;
		this.email = email;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	
	public long getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(long phoneNum) {
		this.phoneNum = phoneNum;
	}


	public Hashtable<String, Integer> getDob() {
		return dob;
	}
	public void setDob(Hashtable<String, Integer> dob) {
		this.dob = dob;
	}


	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
