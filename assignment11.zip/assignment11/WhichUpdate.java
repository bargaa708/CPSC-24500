/*
 * This is class simply supliess an information pane asking the user to input
 * which user they would like to update in the arraylist it then passes that
 * input to the UpdateWindow class.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class WhichUpdate {
	
	String temp;//temp variable to recieve user input the variable will then be parced
	int user;
	UpdateWindow updateWindow;
	
	public int getUser() {
		return user;
	}
	public void setUser(int user) {
		this.user = user;
	}
	
	private ArrayList<Person> arrayList = new ArrayList<Person>();

	public WhichUpdate(ArrayList<Person> arraylist) {
		this.arrayList = arraylist;
		int size = arrayList.size() - 1;
		temp = JOptionPane.showInputDialog("Which user would you like to update (enter a "
				+ "user number (0 - " + size + "):");
		
		user = Integer.parseInt(temp);//parse temp variable so it can be retrieved in the Updatewindow
		
		updateWindow = new UpdateWindow(arrayList, user);
		
	}
	
}
