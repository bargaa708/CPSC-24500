/*
 * This is the Main class for the main GUI window that the user will use it contains 
 * the following buttons: add, load, update, delete, exit, save. most of these 
 * simply call other gui windows/classes.
 * Name:	   Bartlomiej Bielski
 * Class: 	   CPSC-24500-004
 * Assignment: 11
 * Professor:  Dr. Sheikh Shamsuddin
 */

package assignment11;

import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Menu  extends JFrame implements ActionListener{
	private JButton add = new JButton("Add To File");
	private JButton load = new JButton("Load File");
	private JButton update = new JButton("Update File");
	private JButton delete = new JButton("Delete From File");
	private JButton exit = new JButton("Exit");
	private JButton save = new JButton("Save/Serialize");
	
	//arraylist to store person objects
	private ArrayList<Person> arrayList = new ArrayList<Person>();
			
	//getter and setter for arraylist (setter not really necessary)
	public ArrayList<Person> getArrayList() {
		return arrayList;
	}

	public void setArrayList(ArrayList<Person> arrayList) {
		this.arrayList = arrayList;
	}
			
	//method for adding person objects to arraylist
	public void addArrayList(Person person) {
		this.arrayList.add(person);
	}
	
	public Menu(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(400,350);
		this.setVisible(true);
		this.setLayout(null);
		
		add.setBounds(100,5,200,40);
		add.addActionListener(this);
		load.setBounds(100,50,200,40);
		load.addActionListener(this);
		update.setBounds(100,100,200,40);
		update.addActionListener(this);
		delete.setBounds(100,150,200,40);
		delete.addActionListener(this);
		exit.setBounds(100,200,200,40);
		exit.addActionListener(this);
		save.setBounds(100,250,200,40);
		save.addActionListener(this);
		
		this.add(add);
		this.add(load);
		this.add(update);
		this.add(delete);
		this.add(exit);
		this.add(save);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==add) {
			this.dispose();
			AddWindow addWindow = new AddWindow(arrayList);
		}
		if(e.getSource()==load) {
			//this.dispose();
			LoadPane loadPane = new LoadPane();
		}
		if(e.getSource()==update) {
			this.dispose();
			WhichUpdate whichUpdate = new WhichUpdate(arrayList);
		}
		if(e.getSource()==delete) {
			this.dispose();
			WhichDelete whichDelete = new WhichDelete(arrayList);
		}
		if(e.getSource()==exit) {
			System.exit(getDefaultCloseOperation());
		}
		if(e.getSource()==save) {
			SavePane savePane = new SavePane(arrayList);
		}
		
	}
}
